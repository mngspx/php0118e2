<?php
$mang1 = array('xanh','do','tim','vang');
 
 
echo '<pre>'.__FILE__.'::'.__METHOD__.'('.__LINE__.')';
	print_r($mang1);
echo '</pre>';

sort($mang1);

echo '<pre>'.__FILE__.'::'.__METHOD__.'('.__LINE__.')';
	print_r($mang1);
echo '</pre>';