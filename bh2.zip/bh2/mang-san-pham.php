<meta charset="utf-8">
<?php

// $mang_mau_sac = array();
// for($i = 1; $i<=5; $i++){
// 	$mang_mau_sac[] = 'Màu số '. $i;
// }

// echo '<pre>'.__FILE__.'::'.__METHOD__.'('.__LINE__.')';
// 	print_r($mang_mau_sac);
// echo '</pre>';

// $mangSP = array();
// for($i = 1; $i<= 5; $i++){
// 	$mangSP[$i] = 'Sản phẩm  ' .$i;
// }

// echo '<pre>'.__FILE__.'::'.__METHOD__.'('.__LINE__.')';
// 	print_r($mangSP);
// echo '</pre>';