<h1>Nội dung trang giới thiệu</h1>
<?php
	// setcookie('ten_cookie','gia_tri_cookie','Thoi_gian_ton_Tai');
	setcookie('page_da_xem','trang-gioi-thieu.php',time() + 10 * 60 );
	setcookie('page_da_xem2','trang-gioi-thieu.php',time() + 10 * 60 );
	setcookie('page_da_xem3','trang-gioi-thieu.php',time() + 10 * 60 );
	setcookie('page_da_xem4','trang-gioi-thieu.php',time() + 10 * 60 );
	setcookie('page_da_xem5','trang-gioi-thieu.php',time() + 10 * 60 );

?>