<ul>
	<li><a href="index.php?page=trangchu">Trang chủ</a></li>
	<li><a href="index.php?page=gioithieu">Giới thiệu</a></li>
	<li><a href="index.php?page=dangnhap">Đăng nhập</a></li>
	<li><a href="index.php?page=dangxuat">Đăng xuất</a></li>
	<li><a href="index.php?page=quantri">Quản trị</a></li>
</ul>
<div class="clr"></div>